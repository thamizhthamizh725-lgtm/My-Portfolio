const typing = document.querySelector(".typing");

const textArray = [
    "Full Stack Developer",
    "Python Developer",
    "AI & ML Enthusiast",
    "Data Analytics Learner",
    "Web Developer"
];

let textIndex = 0;
let charIndex = 0;
let deleting = false;

function typeEffect() {
    const current = textArray[textIndex];
    if (!deleting) {
        typing.innerHTML = current.substring(0, charIndex);
        charIndex++;
        if (charIndex > current.length) {
            deleting = true;
            setTimeout(typeEffect, 1200);
            return;
        }
    } else {
        typing.innerHTML = current.substring(0, charIndex);
        charIndex--;
        if (charIndex < 0) {
            deleting = false;
            textIndex++;
            if (textIndex >= textArray.length) {
                textIndex = 0;
            }
        }
    }
    setTimeout(typeEffect, deleting ? 70 : 120);
}

typeEffect();

window.addEventListener("scroll", function () {
    let nav = document.querySelector(".navbar");
    if (window.scrollY > 50) {
        nav.style.background = "rgba(0,0,0,.95)";
        nav.style.transition = ".4s";
    } else {
        nav.style.background = "rgba(0,0,0,.40)";
    }
});

document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener("click", function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute("href")).scrollIntoView({
            behavior: "smooth"
        });
    });
});

const sections = document.querySelectorAll("section");
const navLinks = document.querySelectorAll(".nav-link");

window.addEventListener("scroll", () => {
    let current = "";
    sections.forEach(section => {
        const top = section.offsetTop - 150;
        const height = section.clientHeight;
        if (pageYOffset >= top && pageYOffset < top + height) {
            current = section.getAttribute("id");
        }
    });
    navLinks.forEach(link => {
        link.classList.remove("active");
        if (link.getAttribute("href") == "#" + current) {
            link.classList.add("active");
        }
    });
});

// Staggered reveal on scroll using IntersectionObserver
const revealItems = document.querySelectorAll(".card, section h2, .skill-card, .project-slider");

revealItems.forEach(item => item.classList.add("reveal-hidden"));

const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
            setTimeout(() => {
                entry.target.classList.remove("reveal-hidden");
                entry.target.classList.add("in-view");
            }, i * 80);
            revealObserver.unobserve(entry.target);
        }
    });
}, { threshold: 0.15 });

revealItems.forEach(item => revealObserver.observe(item));

// Animate skill bars when they scroll into view
const skillFills = document.querySelectorAll(".skill-fill");
const skillObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const fill = entry.target;
            const percent = fill.getAttribute("data-percent");
            fill.style.width = percent + "%";
            skillObserver.unobserve(fill);
        }
    });
}, { threshold: 0.4 });

skillFills.forEach(fill => skillObserver.observe(fill));

const topBtn = document.createElement("button");
topBtn.innerHTML = "↑";
document.body.appendChild(topBtn);

topBtn.style.position = "fixed";
topBtn.style.right = "20px";
topBtn.style.bottom = "20px";
topBtn.style.width = "50px";
topBtn.style.height = "50px";
topBtn.style.borderRadius = "50%";
topBtn.style.border = "none";
topBtn.style.fontSize = "24px";
topBtn.style.cursor = "pointer";
topBtn.style.background = "#00d4ff";
topBtn.style.color = "#fff";
topBtn.style.display = "none";
topBtn.style.boxShadow = "0 0 20px cyan";
topBtn.style.zIndex = "999";

window.addEventListener("scroll", () => {
    if (window.scrollY > 300) {
        topBtn.style.display = "block";
    } else {
        topBtn.style.display = "none";
    }
});

topBtn.onclick = function () {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
};

// 3D tilt effect on cards, following the cursor
const cards = document.querySelectorAll(".card");
cards.forEach(card => {
    card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const rotateX = ((y / rect.height) - 0.5) * -12;
        const rotateY = ((x / rect.width) - 0.5) * 12;
        card.style.transform = `perspective(700px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-8px) scale(1.02)`;
    });
    card.addEventListener("mouseleave", () => {
        card.style.transform = "perspective(700px) rotateX(0) rotateY(0) translateY(0) scale(1)";
    });
});

// Scroll progress bar
const scrollProgress = document.getElementById("scrollProgress");
window.addEventListener("scroll", () => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const percent = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;
    if (scrollProgress) scrollProgress.style.width = percent + "%";
});

// Cursor glow (desktop only)
const cursorGlow = document.getElementById("cursorGlow");
if (cursorGlow && window.matchMedia("(hover: hover) and (pointer: fine)").matches) {
    window.addEventListener("mousemove", (e) => {
        cursorGlow.style.left = e.clientX + "px";
        cursorGlow.style.top = e.clientY + "px";
    });
}

// Ambient floating particles in the hero canvas
const particleCanvas = document.getElementById("particles");
if (particleCanvas) {
    const ctx = particleCanvas.getContext("2d");
    let particles = [];
    const colors = ["#00ffd5", "#ff00ff", "#ffff00", "#00ffff"];

    function resizeCanvas() {
        particleCanvas.width = particleCanvas.offsetWidth;
        particleCanvas.height = particleCanvas.offsetHeight;
    }

    function createParticles() {
        const count = Math.min(70, Math.floor((particleCanvas.width * particleCanvas.height) / 14000));
        particles = Array.from({ length: count }, () => ({
            x: Math.random() * particleCanvas.width,
            y: Math.random() * particleCanvas.height,
            r: Math.random() * 2 + 1,
            dx: (Math.random() - 0.5) * 0.4,
            dy: (Math.random() - 0.5) * 0.4,
            color: colors[Math.floor(Math.random() * colors.length)]
        }));
    }

    function animateParticles() {
        ctx.clearRect(0, 0, particleCanvas.width, particleCanvas.height);
        particles.forEach(p => {
            p.x += p.dx;
            p.y += p.dy;
            if (p.x < 0 || p.x > particleCanvas.width) p.dx *= -1;
            if (p.y < 0 || p.y > particleCanvas.height) p.dy *= -1;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = p.color;
            ctx.globalAlpha = 0.7;
            ctx.fill();
        });

        // connect nearby particles with faint lines
        for (let i = 0; i < particles.length; i++) {
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < 110) {
                    ctx.beginPath();
                    ctx.strokeStyle = "rgba(0,255,213,0.15)";
                    ctx.lineWidth = 1;
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.stroke();
                }
            }
        }

        requestAnimationFrame(animateParticles);
    }

    resizeCanvas();
    createParticles();
    animateParticles();

    window.addEventListener("resize", () => {
        resizeCanvas();
        createParticles();
    });
}

window.onload = () => {
    console.log("Welcome to Thamizhselvi Portfolio");
};